Autores: João Pedro de Moura Medeiros 21100803 e Andressa Moreira Paulo da Rosa 19204096
Data: 06/09/2022

---------------------------------------- COMO UTILIZAR ----------------------------------------

- As bibliotecas BeautifulSoup, request, time, rs, pandas, numpy e hashlib foram utilizadas no programa.
- O arquivo tarefa1.ipynb faz um crawler que navega pelas páginas de países. 
- O arquivo tarefa1 baixa os HTMLs, salvando-os. 
- O arquivo tarefa1 faz scraping dos HTMLs baixados e os dados retirados são salvos no csv chamado tarefa1.csv
- O arquivo tarefa1 salva uma coluna extra no csv contendo o timestamp do momento no qual os dados foram obtidos. 
- O arquivo tarefa1 faz um crawler que monitora as páginas de países através de um While True procurando por atualizações. Atualizando o csv tarefa1.csv quando alguma mudança ocorre. 
- Para executar o programa você deve utilizar o comando "Run All" do jupyter notebook.
- Na última célula do programa existe um While True, esse laço fica eternamente verificando se existem alterações na página, para parar o programa você deve interromper essa célula.